
<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $__env->make('admin.adminCss', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body>
    <div>
        <?php echo $__env->make('admin.adminHeader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div class="container-scroller" style="margin-top: 80px">
        <?php echo $__env->make('admin.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="col-md-8  mx-auto" style="position: relative; margin-top: 50px">
            <h2 class="text-center">User List</h2>
            <table class="table">
                <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">First</th>
                    <th scope="col">Last</th>
                    <th scope="col">Handle</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($data->name); ?></td>
                    <td><?php echo e($data->email); ?></td>
                    <?php if($data->usertype=="0"): ?>
                    <td><a href="<?php echo e(url('/deleteUser',$data->id)); ?>" onclick="return confirm('are you sure to delete this')">Delete</a></td>
                    <?php else: ?>
                    <td><a>Not Allowed</a></td>
                    <?php endif; ?>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
        <?php echo $__env->make('admin.adminCsript', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH D:\Laravel Project\Restuarent\resources\views/admin/users.blade.php ENDPATH**/ ?>