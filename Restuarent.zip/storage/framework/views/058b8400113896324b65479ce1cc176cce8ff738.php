
<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $__env->make('admin.adminCss', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body>
<div>
    <?php echo $__env->make('admin.adminHeader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<div class="container-scroller" style="margin-top:120px">
    <?php echo $__env->make('admin.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="col-md-8 mx-auto">
                <table class="table" style="width:100%">
                    <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Name</th>
                        <th scope="col">Phone</th>
                        <th scope="col">Address</th>
                        <th scope="col">Food Name</th>
                        <th scope="col">Price</th>
                        <th scope="col">Quantity</th>
                        <th scope="col">total Price</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($data->name); ?></td>
                        <td><?php echo e($data->phone); ?></td>
                        <td><?php echo e($data->address); ?></td>
                        <td><?php echo e($data->foodname); ?></td>
                        <td><?php echo e($data->price); ?></td>
                        <td><?php echo e($data->quantity); ?></td>
                        <td><?php echo e($data->price * $data->quantity); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
</div>
</script>

    <?php echo $__env->make('admin.adminCsript', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH D:\Laravel Project\Restuarent\resources\views/admin/orders.blade.php ENDPATH**/ ?>