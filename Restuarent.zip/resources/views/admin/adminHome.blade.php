
<!DOCTYPE html>
<html lang="en">
<head>
    @include('admin.adminCss')
</head>
<body>
<div>
    @include('admin.adminHeader')
</div>
    @include('admin.navbar')

    @include('admin.adminCsript')
</body>
</html>
